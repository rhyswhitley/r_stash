#ifndef _extras_H
#define _extras_H

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

//const void loadbar(const unsigned int x, const unsigned int n, const unsigned int w);
void progress_bar(const double x, const double N);

#endif
